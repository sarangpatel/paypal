<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .gratitude {
            width: fit-content;
            margin: auto;
            text-align: center;
            font-size: 1.8rem;
        }
        .hello {
            color:rgb(220, 117, 79);
            font-family: "Oswald", sans-serif;
            
        }

    </style>
</head>
<body>
    <section class="gratitude">
        <img src="img/THANK YOU PAGE 1920 x 878.jpg" alt="THANK YOU PAGE">
        <p class="hello">
            Hello <?php echo $name; ?>
        </p>
        <p>Thank you for shopping with us.</p>
        <p>YOUR ORDER #<?php echo $order_id; ?></p>
        <p>We'll send a confirmation when your items ship.</p>
    </section>
</body>
</html>