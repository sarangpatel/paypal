var PAYPAL_COUNTRY_CODE =[
{ country:'albania', iso_code: 'AL' },
{ country:'algeria', iso_code: 'DZ' },
{ country:'andorra', iso_code: 'AD' },
{ country:'angola', iso_code: 'AO' },
{ country:'anguilla', iso_code: 'AI' },
{ country:'antigua & barbuda', iso_code: 'AG' },
{ country:'argentina', iso_code: 'AR' },
{ country:'armenia', iso_code: 'AM' },
{ country:'aruba', iso_code: 'AW' },
{ country:'australia', iso_code: 'AU' },
{ country:'austria', iso_code: 'AT' },
{ country:'azerbaijan', iso_code: 'AZ' },
{ country:'bahamas', iso_code: 'BS' },
{ country:'bahrain', iso_code: 'BH' },
{ country:'barbados', iso_code: 'BB' },
{ country:'belarus', iso_code: 'BY' },
{ country:'belgium', iso_code: 'BE' },
{ country:'belize', iso_code: 'BZ' },
{ country:'benin', iso_code: 'BJ' },
{ country:'bermuda', iso_code: 'BM' },
{ country:'bhutan', iso_code: 'BT' },
{ country:'bolivia', iso_code: 'BO' },
{ country:'bosnia & herzegovina', iso_code: 'BA' },
{ country:'botswana', iso_code: 'BW' },
{ country:'brazil', iso_code: 'BR' },
{ country:'british virgin islands', iso_code: 'VG' },
{ country:'brunei', iso_code: 'BN' },
{ country:'bulgaria', iso_code: 'BG' },
{ country:'burkina faso', iso_code: 'BF' },
{ country:'burundi', iso_code: 'BI' },
{ country:'cambodia', iso_code: 'KH' },
{ country:'cameroon', iso_code: 'CM' },
{ country:'canada', iso_code: 'CA' },
{ country:'cape verde', iso_code: 'CV' },
{ country:'cayman islands', iso_code: 'KY' },
{ country:'chad', iso_code: 'TD' },
{ country:'chile', iso_code: 'CL' },
{ country:'china', iso_code: 'C2' },
{ country:'colombia', iso_code: 'CO' },
{ country:'comoros', iso_code: 'KM' },
{ country:'congo - brazzaville', iso_code: 'CG' },
{ country:'congo - kinshasa', iso_code: 'CD' },
{ country:'cook islands', iso_code: 'CK' },
{ country:'costa rica', iso_code: 'CR' },
{ country:'cÔte d’ivoire', iso_code: 'CI' },
{ country:'croatia', iso_code: 'HR' },
{ country:'cyprus', iso_code: 'CY' },
{ country:'czech republic', iso_code: 'CZ' },
{ country:'denmark', iso_code: 'DK' },
{ country:'djibouti', iso_code: 'DJ' },
{ country:'dominica', iso_code: 'DM' },
{ country:'dominican republic', iso_code: 'DO' },
{ country:'ecuador', iso_code: 'EC' },
{ country:'egypt', iso_code: 'EG' },
{ country:'el salvador', iso_code: 'SV' },
{ country:'eritrea', iso_code: 'ER' },
{ country:'estonia', iso_code: 'EE' },
{ country:'ethiopia', iso_code: 'ET' },
{ country:'falkland islands', iso_code: 'FK' },
{ country:'faroe islands', iso_code: 'FO' },
{ country:'fiji', iso_code: 'FJ' },
{ country:'finland', iso_code: 'FI' },
{ country:'france', iso_code: 'FR' },
{ country:'french guiana', iso_code: 'GF' },
{ country:'french polynesia', iso_code: 'PF' },
{ country:'gabon', iso_code: 'GA' },
{ country:'gambia', iso_code: 'GM' },
{ country:'georgia', iso_code: 'GE' },
{ country:'germany', iso_code: 'DE' },
{ country:'gibraltar', iso_code: 'GI' },
{ country:'greece', iso_code: 'GR' },
{ country:'greenland', iso_code: 'GL' },
{ country:'grenada', iso_code: 'GD' },
{ country:'guadeloupe', iso_code: 'GP' },
{ country:'guatemala', iso_code: 'GT' },
{ country:'guinea', iso_code: 'GN' },
{ country:'guinea-bissau', iso_code: 'GW' },
{ country:'guyana', iso_code: 'GY' },
{ country:'honduras', iso_code: 'HN' },
{ country:'hong kong sar china', iso_code: 'HK' },
{ country:'hungary', iso_code: 'HU' },
{ country:'iceland', iso_code: 'IS' },
{ country:'india', iso_code: 'IN' },
{ country:'indonesia', iso_code: 'ID' },
{ country:'ireland', iso_code: 'IE' },
{ country:'israel', iso_code: 'IL' },
{ country:'italy', iso_code: 'IT' },
{ country:'jamaica', iso_code: 'JM' },
{ country:'japan', iso_code: 'JP' },
{ country:'jordan', iso_code: 'JO' },
{ country:'kazakhstan', iso_code: 'KZ' },
{ country:'kenya', iso_code: 'KE' },
{ country:'kiribati', iso_code: 'KI' },
{ country:'kuwait', iso_code: 'KW' },
{ country:'kyrgyzstan', iso_code: 'KG' },
{ country:'laos', iso_code: 'LA' },
{ country:'latvia', iso_code: 'LV' },
{ country:'lesotho', iso_code: 'LS' },
{ country:'liechtenstein', iso_code: 'LI' },
{ country:'lithuania', iso_code: 'LT' },
{ country:'luxembourg', iso_code: 'LU' },
{ country:'macedonia', iso_code: 'MK' },
{ country:'madagascar', iso_code: 'MG' },
{ country:'malawi', iso_code: 'MW' },
{ country:'malaysia', iso_code: 'MY' },
{ country:'maldives', iso_code: 'MV' },
{ country:'mali', iso_code: 'ML' },
{ country:'malta', iso_code: 'MT' },
{ country:'marshall islands', iso_code: 'MH' },
{ country:'martinique', iso_code: 'MQ' },
{ country:'mauritania', iso_code: 'MR' },
{ country:'mauritius', iso_code: 'MU' },
{ country:'mayotte', iso_code: 'YT' },
{ country:'mexico', iso_code: 'MX' },
{ country:'micronesia', iso_code: 'FM' },
{ country:'moldova', iso_code: 'MD' },
{ country:'monaco', iso_code: 'MC' },
{ country:'mongolia', iso_code: 'MN' },
{ country:'montenegro', iso_code: 'ME' },
{ country:'montserrat', iso_code: 'MS' },
{ country:'morocco', iso_code: 'MA' },
{ country:'mozambique', iso_code: 'MZ' },
{ country:'namibia', iso_code: 'NA' },
{ country:'nauru', iso_code: 'NR' },
{ country:'nepal', iso_code: 'NP' },
{ country:'netherlands', iso_code: 'NL' },
{ country:'new caledonia', iso_code: 'NC' },
{ country:'new zealand', iso_code: 'NZ' },
{ country:'nicaragua', iso_code: 'NI' },
{ country:'niger', iso_code: 'NE' },
{ country:'nigeria', iso_code: 'NG' },
{ country:'niue', iso_code: 'NU' },
{ country:'norfolk island', iso_code: 'NF' },
{ country:'norway', iso_code: 'NO' },
{ country:'oman', iso_code: 'OM' },
{ country:'palau', iso_code: 'PW' },
{ country:'panama', iso_code: 'PA' },
{ country:'papua new guinea', iso_code: 'PG' },
{ country:'paraguay', iso_code: 'PY' },
{ country:'peru', iso_code: 'PE' },
{ country:'philippines', iso_code: 'PH' },
{ country:'pitcairn islands', iso_code: 'PN' },
{ country:'poland', iso_code: 'PL' },
{ country:'portugal', iso_code: 'PT' },
{ country:'qatar', iso_code: 'QA' },
{ country:'rÉunion', iso_code: 'RE' },
{ country:'romania', iso_code: 'RO' },
{ country:'russia', iso_code: 'RU' },
{ country:'rwanda', iso_code: 'RW' },
{ country:'samoa', iso_code: 'WS' },
{ country:'san marino', iso_code: 'SM' },
{ country:'sÃo tomÉ & prÍncipe', iso_code: 'ST' },
{ country:'saudi arabia', iso_code: 'SA' },
{ country:'senegal', iso_code: 'SN' },
{ country:'serbia', iso_code: 'RS' },
{ country:'seychelles', iso_code: 'SC' },
{ country:'sierra leone', iso_code: 'SL' },
{ country:'singapore', iso_code: 'SG' },
{ country:'slovakia', iso_code: 'SK' },
{ country:'slovenia', iso_code: 'SI' },
{ country:'solomon islands', iso_code: 'SB' },
{ country:'somalia', iso_code: 'SO' },
{ country:'south africa', iso_code: 'ZA' },
{ country:'south korea', iso_code: 'KR' },
{ country:'spain', iso_code: 'ES' },
{ country:'sri lanka', iso_code: 'LK' },
{ country:'st. helena', iso_code: 'SH' },
{ country:'st. kitts & nevis', iso_code: 'KN' },
{ country:'st. lucia', iso_code: 'LC' },
{ country:'st. pierre & miquelon', iso_code: 'PM' },
{ country:'st. vincent & grenadines', iso_code: 'VC' },
{ country:'suriname', iso_code: 'SR' },
{ country:'svalbard & jan mayen', iso_code: 'SJ' },
{ country:'swaziland', iso_code: 'SZ' },
{ country:'sweden', iso_code: 'SE' },
{ country:'switzerland', iso_code: 'CH' },
{ country:'taiwan', iso_code: 'TW' },
{ country:'tajikistan', iso_code: 'TJ' },
{ country:'tanzania', iso_code: 'TZ' },
{ country:'thailand', iso_code: 'TH' },
{ country:'togo', iso_code: 'TG' },
{ country:'tonga', iso_code: 'TO' },
{ country:'trinidad & tobago', iso_code: 'TT' },
{ country:'tunisia', iso_code: 'TN' },
{ country:'turkmenistan', iso_code: 'TM' },
{ country:'turks & caicos islands', iso_code: 'TC' },
{ country:'tuvalu', iso_code: 'TV' },
{ country:'uganda', iso_code: 'UG' },
{ country:'ukraine', iso_code: 'UA' },
{ country:'united arab emirates', iso_code: 'AE' },
{ country:'united kingdom', iso_code: 'GB' },
{ country:'united states', iso_code: 'US' },
{ country:'uruguay', iso_code: 'UY' },
{ country:'vanuatu', iso_code: 'VU' },
{ country:'vatican city', iso_code: 'VA' },
{ country:'venezuela', iso_code: 'VE' },
{ country:'vietnam', iso_code: 'VN' },
{ country:'wallis & futuna', iso_code: 'WF' },
{ country:'yemen', iso_code: 'YE' },
{ country:'zambia', iso_code: 'ZM' },
{ country:'zimbabwe', iso_code: 'ZW' }
];

function getPayPalCountryCode(country_name){
    let result = PAYPAL_COUNTRY_CODE.find(c => c.country == country_name);
    if(result !== undefined){
        return result.iso_code;
    }else{
        return 'US';
    } 
}

function checkOrderFormSubmit(){
    const form = document.getElementById('form');
    let frmValid = true;
    let productSelected = false;
    const orderItem = document.querySelectorAll('.order-item');

    if (!form) return
      const items = form.querySelectorAll('.intro-form__item')
  
      items.forEach(item => {
        if (!item.value) {
          //e.preventDefault()
          frmValid = false;
          item.style.borderColor = 'red'
          item.style.boxShadow = '0 0 0 0.1rem rgb(220 53 69 / 100%)'
  
          item.addEventListener('focusin', function() {
            item.style.borderColor = null
            item.style.boxShadow = null
          })
        }
      });
      orderItem.forEach((i) => {
        if(i.classList.contains('selected')){
            document.getElementById('product-err-msg').style.display = 'none';
            productSelected = true;
        }
      });
      if(frmValid){
        if(!productSelected){
            document.getElementById('product-err-msg').style.display = 'block';
            return false;
        }
        return true;
      }else{
        return false;
      }
}

